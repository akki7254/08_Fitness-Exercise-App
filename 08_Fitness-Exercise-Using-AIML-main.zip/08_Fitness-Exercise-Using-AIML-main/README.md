# 08_Fitness-Exercise-Using-AIML
A fitness exercise website to track exercise using mediapipe and opencv
